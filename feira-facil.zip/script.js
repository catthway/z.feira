
function abrirCatalogo() {
  document.getElementById('inicio').style.display = 'none';
  document.getElementById('catalogo').style.display = 'block';
  document.getElementById('carrinho').style.display = 'block';
}
